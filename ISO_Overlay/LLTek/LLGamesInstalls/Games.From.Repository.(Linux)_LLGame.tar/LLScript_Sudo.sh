#!/bin/bash

sudo apt install --yes lbreakout2 kmahjongg kmines kpat ksudoku hedgewars supertux supertuxkart pingus fillets-ng frogatto gnome-mahjongg minetest neverball neverputt frozen-bubble hex-a-hop kbounce knetwalk xmoto aisleriot palapeli dreamchess berusky quadrapassel kgoldrunner ksquares

sudo cp -R ./usr/. /usr
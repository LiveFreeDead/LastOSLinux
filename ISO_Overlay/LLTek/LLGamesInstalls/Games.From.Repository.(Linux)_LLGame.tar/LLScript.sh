#!/bin/bash

cp -R ./Patch/. $HOME
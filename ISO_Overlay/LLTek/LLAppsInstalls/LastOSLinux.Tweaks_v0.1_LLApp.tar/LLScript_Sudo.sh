#!/bin/bash

#Make KDE and QT5 dark mode
sudo apt install -y  qt5ct adwaita-qt
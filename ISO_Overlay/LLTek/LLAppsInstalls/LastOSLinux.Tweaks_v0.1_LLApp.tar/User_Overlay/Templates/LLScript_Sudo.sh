#!/bin/bash

#Add package names and unremark to install from apt
#sudo apt install -y 



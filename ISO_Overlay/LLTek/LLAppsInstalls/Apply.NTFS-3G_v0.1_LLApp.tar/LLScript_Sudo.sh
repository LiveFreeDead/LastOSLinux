#!/bin/bash

#Revert the newer NTFS3 to ntfs-3g
echo 'blacklist ntfs3' | sudo tee /etc/modprobe.d/disable-ntfs3.conf

#Easily reversible by deleting with rm /etc/modprobe.d/disable-ntfs3.conf
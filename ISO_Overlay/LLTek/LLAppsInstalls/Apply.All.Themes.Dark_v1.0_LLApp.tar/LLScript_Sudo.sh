#!/bin/bash

sudo cp -rf ./Overlay/. $HOME/

#Set Dark Theme
sudo gsettings set org.cinnamon.desktop.interface gtk-theme "LastOS-Orchis-Dark-Compact"
sudo gsettings set org.cinnamon.theme name "LastOS-Orchis-Dark-Compact"
sudo gsettings set org.x.apps.portal color-scheme "prefer-dark"
#!/bin/bash

wine regedit /s ./Wine.reg

cp -rf ./Overlay/. $HOME/

#Set Dark Theme
gsettings set org.cinnamon.desktop.interface gtk-theme "LastOS-Orchis-Dark-Compact"
gsettings set org.cinnamon.theme name "LastOS-Orchis-Dark-Compact"
gsettings set org.gnome.desktop.interface gtk-theme "LastOS-Orchis-Dark-Compact"
gsettings set org.x.apps.portal color-scheme "prefer-dark"
#!/bin/bash

#Add "org.name.thing" below and unremark to install a Flatpak
#x-terminal-emulator -e "flatpak install --system -y --noninteractive flathub "



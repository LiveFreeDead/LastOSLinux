#!/bin/bash
zenity --password --title="Authenticate"

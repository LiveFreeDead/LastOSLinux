#!/bin/bash

sudo cp -rf ./Overlay/. $HOME/

#Set Theme
sudo gsettings set org.cinnamon.desktop.interface gtk-theme "Mint-Y-Grey"
sudo gsettings set org.cinnamon.theme name "Mint-Y-Grey"
sudo gsettings set org.gnome.desktop.interface gtk-theme "Mint-Y-Grey"
sudo gsettings set org.x.apps.portal color-scheme "prefer-light"
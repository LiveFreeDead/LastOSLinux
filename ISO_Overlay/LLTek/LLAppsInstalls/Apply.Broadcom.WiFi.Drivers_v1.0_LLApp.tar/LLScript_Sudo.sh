#!/bin/bash

sudo apt remove -y bcmwl-kernel-source broadcom-sta-common broadcom-sta-dkms broadcom-sta-source firmware-b43legacy-installer

sudo apt reinstall -y firmware-b43-installer b43-fwcutter
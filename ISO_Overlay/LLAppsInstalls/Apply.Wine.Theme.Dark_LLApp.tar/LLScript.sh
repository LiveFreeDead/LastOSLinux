#!/bin/bash

wine regedit /s ./DarkWine.reg
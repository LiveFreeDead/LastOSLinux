#!/bin/bash

gnome-terminal -e "sudo cp ./nvidia-sleep.sh /usr/bin"
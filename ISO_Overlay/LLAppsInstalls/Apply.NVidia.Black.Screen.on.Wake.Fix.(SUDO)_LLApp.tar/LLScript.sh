#!/bin/bash

x-terminal-emulator -e "sudo cp ./nvidia-sleep.sh /usr/bin"
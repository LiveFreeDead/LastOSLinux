#!/usr/bin/env /bin/bash

echo "Service Ran" > /LastOS/ServiceRan.txt

######################### EXIT LIVE USER ##############################
#Not needed as the filesystem is cloned from the squishfs and not from Live :)
#Exit if live user
#if [ "$(whoami)" == "live" ]; then
#    exit
#fi

#Make symbolic link to llapp
ln -s /LastOS/LastOSLinux_Store/Tools/LLApp/LLApp.gambas /usr/bin/llapp

apt-get update
mintupdate-launcher &

mv /LastOS/Scripts/sudo_firstlogon_service.sh /LastOS/Scripts/sudo_firstlogon_service.sh.disabled

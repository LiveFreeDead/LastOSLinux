#!/bin/bash

sudo add-apt-repository -y ppa:teejee2008/foss
sudo apt update

sudo apt install --yes conky-all conky-manager2
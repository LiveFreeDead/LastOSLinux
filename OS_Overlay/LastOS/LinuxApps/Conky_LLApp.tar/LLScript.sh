#!/bin/bash

cp -f ./conky.desktop $HOME/.config/autostart

cp -rf ./conky $HOME/.config/